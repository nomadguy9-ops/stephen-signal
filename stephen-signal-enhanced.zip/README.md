# Stephen Signal

A minimal, immersive digital gallery experience for a painter who was never meant to be found — until now.

Deployed on [Vercel](https://vercel.com)

---

🖼️ Ambient gallery  
🎧 Subtle audio  
🗣️ Whispered quotes  
